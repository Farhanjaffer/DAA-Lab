//quicksort search in c 

#include <stdio.h>
#include <time.h>

void swap(int *a, int *b) {
  int t = *a;
  *a = *b;
  *b = t;
}

int partition(int array[], int low, int high) {
  
  
  int pivot = array[high];
  
  
  int i = (low - 1);

  
  for (int j = low; j < high; j++) {
    if (array[j] <= pivot) {
        
      
      i++;
      
      
      swap(&array[i], &array[j]);
    }
  }

  
  swap(&array[i + 1], &array[high]);
 
  return (i + 1);
}

int quickSort(int array[], int low, int high) {
  if (low < high) {
    
    int pi = partition(array, low, high);
    
    
    quickSort(array, low, pi - 1);
    
    
    quickSort(array, pi + 1, high);
  }
}

int main(void) {
    clock_t start,end;

    FILE *myFile;
    myFile = fopen("random3.txt", "r");

    //read file into array
    int numberArray[20000];
    int i;

    for (i = 0; i < 20000; i++)
    {
        fscanf(myFile, "%d", &numberArray[i]);
    }

    start=clock();    
int n = sizeof(numberArray) / sizeof(numberArray[0]);

quickSort(numberArray, 0, n - 1);



    end=clock();

    double time=(end-start)/CLOCKS_PER_SEC;
    printf("%f",time);
  
  return 0;
}